package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import model.Modelo;
import factory.ConnectionFactory;

public class AlunoDAO {
    private Connection conexao;

    public AlunoDAO() {
        conexao = ConnectionFactory.getConnection();
    }

    public void inserirAluno(Modelo aluno) {
        String sql = "INSERT INTO alunos (cpf, nome, dataNascimento, peso, altura) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setDouble(1, aluno.getCpf());
            stmt.setString(2, aluno.getNome());
            stmt.setDate(3, new java.sql.Date(aluno.getDataNascimento().getTime()));
            stmt.setDouble(4, aluno.getPeso());
            stmt.setDouble(5, aluno.getAltura());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Modelo> listarAlunos() {
        List<Modelo> alunos = new ArrayList<>();
        String sql = "SELECT * FROM alunos";
        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Modelo aluno = new Modelo(
                        rs.getDouble("cpf"),
                        rs.getString("nome"),
                        rs.getDate("dataNascimento"),
                        rs.getDouble("peso"),
                        rs.getDouble("altura")
                );
                alunos.add(aluno);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return alunos;
    }

    public void atualizarAluno(Modelo aluno) {
        String sql = "UPDATE alunos SET nome = ?, dataNascimento = ?, peso = ?, altura = ? WHERE cpf = ?";
        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, aluno.getNome());
            stmt.setDate(2, new java.sql.Date(aluno.getDataNascimento().getTime()));
            stmt.setDouble(3, aluno.getPeso());
            stmt.setDouble(4, aluno.getAltura());
            stmt.setDouble(5, aluno.getCpf());
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Aluno atualizado com sucesso.");
            } else {
                System.out.println("Nenhum aluno foi atualizado. Verifique se o CPF informado está correto.");
            }
        } catch (SQLException e) {
            System.err.println("Erro ao atualizar aluno: " + e.getMessage());
        }
    }

    public void deletarAluno(double cpf) {
        String sql = "DELETE FROM alunos WHERE cpf = ?";
        try (PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setDouble(1, cpf);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Aluno deletado com sucesso.");
            } else {
                System.out.println("Nenhum aluno foi deletado. Verifique se o CPF informado está correto.");
            }
        } catch (SQLException e) {
            System.err.println("Erro ao deletar aluno: " + e.getMessage());
        }
    }
}
