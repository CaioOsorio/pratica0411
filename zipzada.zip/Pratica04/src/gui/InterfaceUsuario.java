package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import model.Modelo;
import dao.AlunoDAO;

public class InterfaceUsuario extends JFrame {
    private JTextField cpfField;
    private JTextField nomeField;
    private JTextField dataNascimentoField;
    private JTextField pesoField;
    private JTextField alturaField;
    private JButton adicionarButton;
    private JButton atualizarButton;
    private JButton deletarButton;

    private AlunoDAO alunoDAO;

    public InterfaceUsuario() {
        super("Cadastro de Usuário");

        alunoDAO = new AlunoDAO();

        // Criando componentes da interface
        JLabel cpfLabel = new JLabel("CPF:");
        JLabel nomeLabel = new JLabel("Nome:");
        JLabel dataNascimentoLabel = new JLabel("Data de Nascimento (dd/MM/yyyy):");
        JLabel pesoLabel = new JLabel("Peso:");
        JLabel alturaLabel = new JLabel("Altura:");

        cpfField = new JTextField(10);
        nomeField = new JTextField(20);
        dataNascimentoField = new JTextField(10);
        pesoField = new JTextField(5);
        alturaField = new JTextField(5);

        adicionarButton = new JButton("Adicionar");
        atualizarButton = new JButton("Atualizar");
        deletarButton = new JButton("Deletar");

        // Configurando layout da interface
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(6, 2));
        panel.add(cpfLabel);
        panel.add(cpfField);
        panel.add(nomeLabel);
        panel.add(nomeField);
        panel.add(dataNascimentoLabel);
        panel.add(dataNascimentoField);
        panel.add(pesoLabel);
        panel.add(pesoField);
        panel.add(alturaLabel);
        panel.add(alturaField);
        panel.add(adicionarButton);
        panel.add(atualizarButton);
        panel.add(deletarButton);

        add(panel);

        // Configurando ação dos botões
        adicionarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                adicionarUsuario();
            }
        });

        atualizarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                atualizarUsuario();
            }
        });

        deletarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deletarUsuario();
            }
        });

        // Configurações da janela
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null); // Centraliza a janela na tela
        setVisible(true);
    }

    private void adicionarUsuario() {
        double cpf = Double.parseDouble(cpfField.getText());
        String nome = nomeField.getText();
        Date dataNascimento = null;
        try {
            dataNascimento = new SimpleDateFormat("dd/MM/yyyy").parse(dataNascimentoField.getText());
        } catch (ParseException e) {
            JOptionPane.showMessageDialog(this, "Formato de data inválido", "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }
        double peso = Double.parseDouble(pesoField.getText());
        double altura = Double.parseDouble(alturaField.getText());

        Modelo aluno = new Modelo(cpf, nome, dataNascimento, peso, altura);
        alunoDAO.inserirAluno(aluno);
    }

    private void atualizarUsuario() {
        double cpf = Double.parseDouble(cpfField.getText());
        String nome = nomeField.getText();
        Date dataNascimento = null;
        try {
            dataNascimento = new SimpleDateFormat("dd/MM/yyyy").parse(dataNascimentoField.getText());
        } catch (ParseException ex) {
            JOptionPane.showMessageDialog(this, "Formato de data inválido", "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }
        double peso = Double.parseDouble(pesoField.getText());
        double altura = Double.parseDouble(alturaField.getText());

        Modelo aluno = new Modelo(cpf, nome, dataNascimento, peso, altura);
        alunoDAO.atualizarAluno(aluno);
    }

    private void deletarUsuario() {
        double cpf = Double.parseDouble(cpfField.getText());
        alunoDAO.deletarAluno(cpf);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(InterfaceUsuario::new);
    }
}
