package dao;

import Model.Modelo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Date;
import factory.ConnectionFactory;

public class ModeloDAO {
    
        private Connection connection;
        
        public ModeloDAO(){
            this.connection = new ConnectionFactory().getConnection();
            
        }
            
        public void adiciona(Modelo modelo){
        String sql = "INSERT INTO alunos(cpf, nome, dataNascimento, altura, peso) VALUES (?, ?, ?, ?, ?)";
        try{
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setInt(1, modelo.getCpf());
            stmt.setString(2, modelo.getNome());
            stmt.setDate(3, new Date(modelo.getDataNascimento().getTime()));
            stmt.setDouble(4, modelo.getAltura());
            stmt.setDouble(5, modelo.getPeso());
        }
        catch (SQLException u){
            throw new RuntimeException(u);
        }
    }
}